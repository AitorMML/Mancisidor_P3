Practica 3

MIPS Pipeline

IF/ID	x
ID/EX	x	Funciona medio raro
EX/MEM	x 	Funciona m�s raro. implementar WB puede arreglarlo
MEM/WB

Forwarding Unit

Hazard Detection Unit